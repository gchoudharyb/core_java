package com.retail.appservices.pdmupdate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailAppservicesPdmupdateApplicationTests {

	@Test
	void contextLoads() {
	}

}
